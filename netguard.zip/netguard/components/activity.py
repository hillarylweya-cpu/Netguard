import reflex as rx
from netguard.states.dashboard_state import DashboardState, ActivityLogEntry


def log_item(entry: ActivityLogEntry) -> rx.Component:
    return rx.el.div(
        rx.el.div(
            rx.el.div(
                class_name=rx.match(
                    entry["type"],
                    ("success", "w-2 h-2 rounded-full bg-emerald-500"),
                    ("warning", "w-2 h-2 rounded-full bg-amber-500"),
                    ("danger", "w-2 h-2 rounded-full bg-red-500"),
                    "w-2 h-2 rounded-full bg-slate-500",
                )
            ),
            class_name="flex-shrink-0 mt-2",
        ),
        rx.el.div(
            rx.el.div(
                rx.el.p(
                    entry["action"],
                    class_name="text-sm font-medium text-slate-200",
                ),
                rx.el.span(
                    entry["timestamp"],
                    class_name="text-[10px] text-slate-500 font-mono",
                ),
                class_name="flex justify-between items-start",
            ),
            rx.el.p(
                entry["status"],
                class_name=rx.match(
                    entry["type"],
                    (
                        "success",
                        "text-[10px] font-bold text-emerald-500 uppercase",
                    ),
                    (
                        "warning",
                        "text-[10px] font-bold text-amber-500 uppercase",
                    ),
                    ("danger", "text-[10px] font-bold text-red-500 uppercase"),
                    "text-[10px] font-bold text-slate-500 uppercase",
                ),
            ),
            class_name="flex-1 ml-4",
        ),
        class_name="flex items-start py-3 border-b border-slate-800 last:border-0",
    )


def activity_section() -> rx.Component:
    return rx.el.div(
        rx.el.div(
            rx.el.h3(
                "Recent Activity Log",
                class_name="text-lg font-bold text-slate-100",
            ),
            rx.el.button(
                "Export Logs",
                class_name="px-3 py-1 text-[10px] font-bold text-slate-400 border border-slate-700 rounded-md hover:bg-slate-700 transition-colors",
            ),
            class_name="flex justify-between items-center mb-6",
        ),
        rx.el.div(
            rx.foreach(DashboardState.activity_log, log_item),
            class_name="space-y-1 overflow-y-auto max-h-[400px] pr-2 custom-scrollbar",
        ),
        class_name="bg-slate-800 p-6 rounded-xl border border-slate-700 shadow-sm mt-8",
    )