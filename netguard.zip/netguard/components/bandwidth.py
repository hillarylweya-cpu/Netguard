import reflex as rx
from netguard.states.dashboard_state import DashboardState


def department_limit_card(department: str) -> rx.Component:
    limit = DashboardState.department_limits[department]
    return rx.el.div(
        rx.el.div(
            rx.el.div(
                rx.el.h4(department, class_name="text-lg font-bold text-white"),
                rx.el.p(
                    "Current Speed Limit",
                    class_name="text-xs text-slate-500 uppercase font-semibold",
                ),
                class_name="flex flex-col",
            ),
            rx.el.div(
                rx.icon("activity", size=20, class_name="text-emerald-400"),
                class_name="p-2 bg-slate-900 rounded-lg",
            ),
            class_name="flex justify-between items-start mb-6",
        ),
        rx.el.div(
            rx.el.span(
                limit.to_string(),
                class_name="text-4xl font-black text-emerald-400",
            ),
            rx.el.span(" Mbps", class_name="text-slate-500 font-bold ml-1"),
            class_name="mb-6",
        ),
        rx.el.div(
            rx.el.div(
                rx.el.button(
                    rx.icon("minus", size=16),
                    on_click=lambda: DashboardState.adjust_bandwidth(
                        department, -10
                    ),
                    class_name="p-2 bg-slate-900 border border-slate-700 rounded-lg text-slate-400 hover:text-white transition-colors",
                ),
                rx.el.button(
                    rx.icon("plus", size=16),
                    on_click=lambda: DashboardState.adjust_bandwidth(
                        department, 10
                    ),
                    class_name="p-2 bg-emerald-600/20 border border-emerald-600/40 rounded-lg text-emerald-400 hover:bg-emerald-600/30 transition-colors",
                ),
                class_name="flex gap-3",
            ),
            class_name="flex justify-end mt-auto",
        ),
        class_name="bg-slate-800 p-6 rounded-xl border border-slate-700 shadow-sm hover:border-slate-600 transition-colors flex flex-col",
    )


def bandwidth_page() -> rx.Component:
    return rx.el.div(
        rx.el.div(
            rx.el.div(
                rx.el.h2(
                    "Bandwidth Control",
                    class_name="text-2xl font-bold text-white",
                ),
                rx.el.p(
                    "Allocate and monitor network speed limits",
                    class_name="text-slate-400 text-sm",
                ),
                class_name="flex flex-col",
            ),
            rx.el.div(
                rx.el.div(
                    rx.el.div(
                        rx.el.p(
                            "Budget Utilization",
                            class_name="text-[10px] text-slate-500 uppercase font-bold text-right mb-1",
                        ),
                        rx.el.p(
                            f"{DashboardState.total_allocated} / {DashboardState.bandwidth_total} Mbps",
                            class_name="text-sm font-bold text-emerald-400",
                        ),
                        class_name="flex flex-col",
                    ),
                    rx.el.div(
                        rx.el.div(
                            class_name="h-full bg-emerald-500 rounded-full transition-all duration-500",
                            style={
                                "width": f"{DashboardState.total_allocated / DashboardState.bandwidth_total * 100}%"
                            },
                        ),
                        class_name="w-32 h-2 bg-slate-900 rounded-full ml-4 overflow-hidden",
                    ),
                    class_name="flex items-center px-6 py-3 bg-slate-900/50 rounded-xl border border-slate-700",
                ),
                class_name="flex items-center",
            ),
            class_name="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-8",
        ),
        rx.el.div(
            department_limit_card("Staff"),
            department_limit_card("Students"),
            department_limit_card("Labs"),
            department_limit_card("Admin"),
            class_name="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-10",
        ),
        rx.el.div(
            rx.el.div(
                rx.el.h3(
                    "Usage Metrics per Department",
                    class_name="text-lg font-bold text-white mb-6",
                ),
                rx.recharts.bar_chart(
                    rx.recharts.cartesian_grid(
                        horizontal=True, vertical=False, stroke="#334155"
                    ),
                    rx.recharts.graphing_tooltip(
                        content_style={
                            "backgroundColor": "#1e293b",
                            "borderColor": "#334155",
                            "borderRadius": "8px",
                            "color": "#f8fafc",
                        },
                        item_style={"color": "#10b981"},
                    ),
                    rx.recharts.x_axis(
                        data_key="name",
                        stroke="#94a3b8",
                        font_size=12,
                        tick_line=False,
                        axis_line=False,
                    ),
                    rx.recharts.y_axis(
                        stroke="#94a3b8",
                        font_size=12,
                        tick_line=False,
                        axis_line=False,
                    ),
                    rx.recharts.bar(
                        data_key="Usage", fill="#10b981", radius=[4, 4, 0, 0]
                    ),
                    rx.recharts.bar(
                        data_key="Limit", fill="#334155", radius=[4, 4, 0, 0]
                    ),
                    data=DashboardState.bandwidth_chart_data,
                    width="100%",
                    height=300,
                ),
                class_name="bg-slate-800 p-8 rounded-xl border border-slate-700 shadow-sm",
            ),
            class_name="w-full",
        ),
        class_name="p-6 md:p-10 max-w-7xl mx-auto w-full animate-in fade-in duration-500",
    )