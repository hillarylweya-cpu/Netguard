import reflex as rx
from netguard.states.dashboard_state import DashboardState


def blocking_category_card(category: str) -> rx.Component:
    is_enabled = DashboardState.category_enabled[category]
    sites = DashboardState.blocked_sites[category]
    return rx.el.div(
        rx.el.div(
            rx.el.div(
                rx.el.h4(category, class_name="text-lg font-bold text-white"),
                rx.el.span(
                    f"{sites.length()} sites blocked",
                    class_name="text-xs text-slate-500 font-medium",
                ),
                class_name="flex flex-col",
            ),
            rx.el.button(
                rx.el.div(
                    class_name=rx.cond(
                        is_enabled,
                        "w-4 h-4 bg-white rounded-full translate-x-5 transition-transform duration-200",
                        "w-4 h-4 bg-white rounded-full translate-x-0 transition-transform duration-200",
                    )
                ),
                on_click=lambda: DashboardState.toggle_category(category),
                class_name=rx.cond(
                    is_enabled,
                    "w-10 h-5 bg-emerald-600 rounded-full relative p-0.5 transition-colors",
                    "w-10 h-5 bg-slate-700 rounded-full relative p-0.5 transition-colors",
                ),
            ),
            class_name="flex justify-between items-start mb-4",
        ),
        rx.el.div(
            rx.foreach(
                sites,
                lambda url: rx.el.div(
                    rx.el.span(
                        url,
                        class_name="text-xs text-slate-300 font-medium truncate",
                    ),
                    rx.el.button(
                        rx.icon("x", size=12),
                        on_click=lambda: DashboardState.remove_blocked_site(
                            category, url
                        ),
                        class_name="text-slate-500 hover:text-red-400 transition-colors",
                    ),
                    class_name="flex items-center justify-between p-2 bg-slate-900/50 rounded-lg border border-slate-700/50 mb-2",
                ),
            ),
            class_name="space-y-1",
        ),
        class_name=rx.cond(
            is_enabled,
            "bg-slate-800 p-6 rounded-xl border-2 border-emerald-500/30 shadow-sm transition-all",
            "bg-slate-800 p-6 rounded-xl border border-slate-700 opacity-60 grayscale-[0.5] shadow-sm transition-all",
        ),
    )


def site_blocking_page() -> rx.Component:
    return rx.el.div(
        rx.el.div(
            rx.el.div(
                rx.el.h2(
                    "Site & Content Blocking",
                    class_name="text-2xl font-bold text-white",
                ),
                rx.el.p(
                    "Restrict access to specific web domains across the network",
                    class_name="text-slate-400 text-sm",
                ),
                class_name="flex flex-col",
            ),
            class_name="mb-8",
        ),
        rx.el.div(
            rx.el.form(
                rx.el.div(
                    rx.el.div(
                        rx.el.select(
                            rx.el.option("Custom", value="Custom"),
                            rx.el.option("Social Media", value="Social Media"),
                            rx.el.option("Streaming", value="Streaming"),
                            rx.el.option("Gaming", value="Gaming"),
                            on_change=DashboardState.set_selected_category,
                            class_name="bg-slate-900 border border-slate-700 rounded-lg px-4 py-2 text-sm text-slate-200 focus:border-emerald-500 outline-none w-full md:w-48 appearance-none",
                        ),
                        class_name="relative",
                    ),
                    rx.el.input(
                        name="url",
                        placeholder="Enter URL (e.g. reddit.com)",
                        class_name="flex-1 bg-slate-900 border border-slate-700 rounded-lg px-4 py-2 text-sm text-slate-200 focus:border-emerald-500 outline-none",
                    ),
                    rx.el.button(
                        "Add Block",
                        type="submit",
                        class_name="px-6 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg font-bold transition-colors",
                    ),
                    class_name="flex flex-col md:flex-row gap-4 w-full",
                ),
                on_submit=DashboardState.add_blocked_site,
                reset_on_submit=True,
                class_name="bg-slate-800 p-6 rounded-xl border border-slate-700 mb-10 shadow-lg",
            )
        ),
        rx.el.div(
            blocking_category_card("Social Media"),
            blocking_category_card("Streaming"),
            blocking_category_card("Gaming"),
            blocking_category_card("Custom"),
            class_name="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6",
        ),
        class_name="p-6 md:p-10 max-w-7xl mx-auto w-full animate-in fade-in duration-500",
    )