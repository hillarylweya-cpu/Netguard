import reflex as rx
from netguard.states.dashboard_state import DashboardState, Device


def filter_tab(label: str) -> rx.Component:
    is_active = DashboardState.device_filter == label
    count = DashboardState.department_stats[label]
    return rx.el.button(
        rx.el.div(
            rx.el.span(label),
            rx.el.span(
                count.to_string(),
                class_name="ml-2 px-1.5 py-0.5 text-[10px] bg-slate-900 rounded-md text-slate-400 group-hover:text-emerald-400 transition-colors",
            ),
            class_name="flex items-center",
        ),
        on_click=lambda: DashboardState.set_device_filter(label),
        class_name=rx.cond(
            is_active,
            "px-4 py-2 text-sm font-bold text-emerald-400 border-b-2 border-emerald-400",
            "px-4 py-2 text-sm font-medium text-slate-400 hover:text-slate-200 transition-colors group",
        ),
    )


def device_row(device: Device) -> rx.Component:
    return rx.el.tr(
        rx.el.td(
            rx.el.div(
                rx.el.div(
                    rx.icon("laptop", size=16, class_name="text-slate-400"),
                    class_name="p-2 bg-slate-900 rounded-lg mr-3",
                ),
                rx.el.span(
                    device["name"], class_name="font-semibold text-slate-200"
                ),
                class_name="flex items-center",
            ),
            class_name="py-4 px-6",
        ),
        rx.el.td(
            device["ip"],
            class_name="py-4 px-6 text-slate-400 font-mono text-sm",
        ),
        rx.el.td(
            device["mac"],
            class_name="py-4 px-6 text-slate-500 font-mono text-xs",
        ),
        rx.el.td(
            rx.el.div(
                rx.cond(
                    device["status"] == "Online",
                    rx.el.span(
                        "ONLINE",
                        class_name="px-2 py-0.5 text-[10px] font-bold bg-emerald-500/10 text-emerald-500 rounded-full",
                    ),
                    rx.el.span(
                        "OFFLINE",
                        class_name="px-2 py-0.5 text-[10px] font-bold bg-slate-700 text-slate-400 rounded-full",
                    ),
                ),
                class_name="flex",
            ),
            class_name="py-4 px-6",
        ),
        rx.el.td(
            rx.el.span(
                device["department"],
                class_name="px-2 py-1 text-[10px] bg-slate-900 text-slate-400 border border-slate-700 rounded-md",
            ),
            class_name="py-4 px-6",
        ),
        rx.el.td(
            rx.el.button(
                rx.el.div(
                    class_name=rx.cond(
                        device["enabled"],
                        "w-4 h-4 bg-white rounded-full translate-x-5 transition-transform duration-200",
                        "w-4 h-4 bg-white rounded-full translate-x-0 transition-transform duration-200",
                    )
                ),
                on_click=lambda: DashboardState.toggle_device(device["id"]),
                class_name=rx.cond(
                    device["enabled"],
                    "w-10 h-5 bg-emerald-600 rounded-full relative p-0.5 transition-colors",
                    "w-10 h-5 bg-slate-700 rounded-full relative p-0.5 transition-colors",
                ),
            ),
            class_name="py-4 px-6",
        ),
        class_name="border-b border-slate-800 hover:bg-slate-800/30 transition-colors",
    )


def device_management_page() -> rx.Component:
    return rx.el.div(
        rx.el.div(
            rx.el.div(
                rx.el.h2(
                    "Network Devices",
                    class_name="text-2xl font-bold text-white",
                ),
                rx.el.p(
                    "Manage internet access for connected hardware",
                    class_name="text-slate-400 text-sm",
                ),
                class_name="flex flex-col",
            ),
            rx.el.div(
                rx.el.div(
                    rx.icon(
                        "search", size=18, class_name="text-slate-500 mr-2"
                    ),
                    rx.el.input(
                        placeholder="Search by name or IP...",
                        on_change=DashboardState.set_device_search.debounce(
                            300
                        ),
                        class_name="bg-transparent border-none focus:ring-0 text-sm text-slate-200 w-64",
                    ),
                    class_name="flex items-center px-4 py-2 bg-slate-900 rounded-lg border border-slate-700",
                ),
                class_name="flex items-center",
            ),
            class_name="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-8",
        ),
        rx.el.div(
            rx.el.div(
                filter_tab("All"),
                filter_tab("Staff"),
                filter_tab("Students"),
                filter_tab("Labs"),
                filter_tab("Admin"),
                class_name="flex border-b border-slate-800 mb-6",
            ),
            rx.el.div(
                rx.el.table(
                    rx.el.thead(
                        rx.el.tr(
                            rx.el.th(
                                "Device Name",
                                class_name="text-left py-3 px-6 text-xs font-bold text-slate-500 uppercase tracking-wider",
                            ),
                            rx.el.th(
                                "IP Address",
                                class_name="text-left py-3 px-6 text-xs font-bold text-slate-500 uppercase tracking-wider",
                            ),
                            rx.el.th(
                                "MAC Address",
                                class_name="text-left py-3 px-6 text-xs font-bold text-slate-500 uppercase tracking-wider",
                            ),
                            rx.el.th(
                                "Status",
                                class_name="text-left py-3 px-6 text-xs font-bold text-slate-500 uppercase tracking-wider",
                            ),
                            rx.el.th(
                                "Department",
                                class_name="text-left py-3 px-6 text-xs font-bold text-slate-500 uppercase tracking-wider",
                            ),
                            rx.el.th(
                                "Access Control",
                                class_name="text-left py-3 px-6 text-xs font-bold text-slate-500 uppercase tracking-wider",
                            ),
                        ),
                        class_name="bg-slate-900/50",
                    ),
                    rx.el.tbody(
                        rx.foreach(DashboardState.filtered_devices, device_row),
                        class_name="bg-transparent",
                    ),
                    class_name="w-full table-auto",
                ),
                class_name="overflow-x-auto rounded-xl border border-slate-700 bg-slate-800/40 shadow-sm",
            ),
            class_name="w-full",
        ),
        class_name="p-6 md:p-10 max-w-7xl mx-auto w-full animate-in fade-in duration-500",
    )