import reflex as rx
from netguard.states.dashboard_state import DashboardState


def header() -> rx.Component:
    return rx.el.header(
        rx.el.div(
            rx.el.div(
                rx.el.h2(
                    "Westfield University",
                    class_name="text-lg font-bold text-slate-100",
                ),
                rx.el.p(
                    "Campus Network Administration",
                    class_name="text-xs text-slate-400 font-medium",
                ),
                class_name="flex flex-col",
            ),
            rx.el.div(
                rx.el.span(
                    "NET-GUARD",
                    class_name="md:hidden text-emerald-500 font-bold",
                )
            ),
            rx.el.div(
                rx.el.div(
                    rx.el.div(
                        class_name=rx.cond(
                            DashboardState.internet_enabled,
                            "w-2 h-2 rounded-full bg-emerald-500 animate-pulse",
                            "w-2 h-2 rounded-full bg-red-500",
                        )
                    ),
                    rx.el.span(
                        rx.cond(
                            DashboardState.internet_enabled, "Online", "Offline"
                        ),
                        class_name=rx.cond(
                            DashboardState.internet_enabled,
                            "text-xs font-bold text-emerald-500",
                            "text-xs font-bold text-red-500",
                        ),
                    ),
                    class_name="flex items-center gap-2 px-3 py-1.5 bg-slate-900 rounded-full border border-slate-700 mr-4",
                ),
                rx.el.div(
                    rx.el.div(
                        rx.el.p(
                            "Admin Controller",
                            class_name="text-sm font-semibold text-slate-200",
                        ),
                        rx.el.p(
                            "Superuser",
                            class_name="text-[10px] text-slate-500 text-right",
                        ),
                        class_name="flex flex-col items-end mr-3 hidden sm:flex",
                    ),
                    rx.image(
                        src="https://api.dicebear.com/9.x/notionists/svg?seed=admin",
                        class_name="w-9 h-9 rounded-full bg-slate-700 border border-slate-600",
                    ),
                    class_name="flex items-center",
                ),
                class_name="flex items-center",
            ),
            class_name="flex justify-between items-center h-full px-6",
        ),
        class_name="h-16 bg-slate-800/50 backdrop-blur-md border-b border-slate-800 sticky top-0 z-30",
    )