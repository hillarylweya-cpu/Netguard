import reflex as rx
from netguard.states.dashboard_state import DashboardState


def settings_card(title: str, icon: str, content: rx.Component) -> rx.Component:
    return rx.el.div(
        rx.el.div(
            rx.el.div(
                rx.icon(icon, size=20, class_name="text-emerald-400"),
                class_name="p-2 bg-slate-900 rounded-lg mr-3",
            ),
            rx.el.h3(title, class_name="text-lg font-bold text-white"),
            class_name="flex items-center mb-6",
        ),
        content,
        class_name="bg-slate-800 p-8 rounded-xl border border-slate-700 shadow-sm",
    )


def settings_page() -> rx.Component:
    return rx.el.div(
        rx.el.div(
            rx.el.h2(
                "System Settings",
                class_name="text-2xl font-bold text-white mb-2",
            ),
            rx.el.p(
                "Global administration and security preferences",
                class_name="text-slate-400 text-sm mb-8",
            ),
        ),
        rx.el.div(
            settings_card(
                "System Information",
                "info",
                rx.el.div(
                    rx.el.div(
                        rx.el.div(
                            rx.el.p(
                                "App Version",
                                class_name="text-xs text-slate-500 font-bold uppercase",
                            ),
                            rx.el.p(
                                "v2.4.1-stable",
                                class_name="text-slate-200 font-mono",
                            ),
                            class_name="flex flex-col",
                        ),
                        rx.el.div(
                            rx.el.p(
                                "System Uptime",
                                class_name="text-xs text-slate-500 font-bold uppercase",
                            ),
                            rx.el.p(
                                "14 Days, 3:24:12",
                                class_name="text-slate-200 font-mono",
                            ),
                            class_name="flex flex-col",
                        ),
                        class_name="grid grid-cols-2 gap-4 mb-4",
                    ),
                    rx.el.div(
                        rx.el.div(
                            rx.el.p(
                                "Last Restart",
                                class_name="text-xs text-slate-500 font-bold uppercase",
                            ),
                            rx.el.p(
                                "2024-05-12 04:00",
                                class_name="text-slate-200 font-mono",
                            ),
                            class_name="flex flex-col",
                        ),
                        rx.el.div(
                            rx.el.p(
                                "Capacity",
                                class_name="text-xs text-slate-500 font-bold uppercase",
                            ),
                            rx.el.p(
                                "1.2 Gbps Dedicated",
                                class_name="text-slate-200 font-mono",
                            ),
                            class_name="flex flex-col",
                        ),
                        class_name="grid grid-cols-2 gap-4",
                    ),
                    class_name="space-y-4",
                ),
            ),
            settings_card(
                "Admin Account",
                "user",
                rx.el.div(
                    rx.el.p(
                        f"Logged in as: {DashboardState.admin_name}",
                        class_name="text-sm text-slate-400 mb-6 font-semibold",
                    ),
                    rx.el.div(
                        rx.el.input(
                            placeholder="Current Password",
                            type="password",
                            class_name="w-full bg-slate-900 border border-slate-700 rounded-lg px-4 py-2 text-sm mb-3",
                        ),
                        rx.el.input(
                            placeholder="New Password",
                            type="password",
                            class_name="w-full bg-slate-900 border border-slate-700 rounded-lg px-4 py-2 text-sm mb-3",
                        ),
                        rx.el.input(
                            placeholder="Confirm New Password",
                            type="password",
                            class_name="w-full bg-slate-900 border border-slate-700 rounded-lg px-4 py-2 text-sm mb-6",
                        ),
                        rx.el.button(
                            "Update Password",
                            on_click=DashboardState.update_password,
                            class_name="w-full bg-emerald-600 hover:bg-emerald-500 text-white py-2 rounded-lg font-bold transition-all",
                        ),
                    ),
                ),
            ),
            settings_card(
                "Network Config",
                "settings-2",
                rx.el.div(
                    rx.el.div(
                        rx.el.span("Gateway IP", class_name="text-slate-500"),
                        rx.el.span(
                            "10.0.0.1", class_name="text-white font-mono"
                        ),
                        class_name="flex justify-between py-2 border-b border-slate-700/50",
                    ),
                    rx.el.div(
                        rx.el.span("Subnet Mask", class_name="text-slate-500"),
                        rx.el.span(
                            "255.255.255.0", class_name="text-white font-mono"
                        ),
                        class_name="flex justify-between py-2 border-b border-slate-700/50",
                    ),
                    rx.el.div(
                        rx.el.span("Primary DNS", class_name="text-slate-500"),
                        rx.el.span(
                            "1.1.1.1", class_name="text-white font-mono"
                        ),
                        class_name="flex justify-between py-2 border-b border-slate-700/50",
                    ),
                    rx.el.div(
                        rx.el.span(
                            "Secondary DNS", class_name="text-slate-500"
                        ),
                        rx.el.span(
                            "8.8.8.8", class_name="text-white font-mono"
                        ),
                        class_name="flex justify-between py-2",
                    ),
                    class_name="text-sm",
                ),
            ),
            settings_card(
                "Notifications",
                "bell",
                rx.el.div(
                    rx.foreach(
                        DashboardState.notification_prefs.keys(),
                        lambda pref: rx.el.div(
                            rx.el.span(
                                pref.split("_").join(" ").upper(),
                                class_name="text-sm text-slate-300 font-bold",
                            ),
                            rx.el.button(
                                rx.el.div(
                                    class_name=rx.cond(
                                        DashboardState.notification_prefs[pref],
                                        "w-4 h-4 bg-white rounded-full translate-x-5 transition-all",
                                        "w-4 h-4 bg-white rounded-full translate-x-0 transition-all",
                                    )
                                ),
                                on_click=lambda: (
                                    DashboardState.toggle_notification_pref(
                                        pref
                                    )
                                ),
                                class_name=rx.cond(
                                    DashboardState.notification_prefs[pref],
                                    "w-10 h-5 bg-emerald-600 rounded-full relative p-0.5",
                                    "w-10 h-5 bg-slate-700 rounded-full relative p-0.5",
                                ),
                            ),
                            class_name="flex items-center justify-between mb-4 last:mb-0",
                        ),
                    )
                ),
            ),
            class_name="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8",
        ),
        rx.el.div(
            rx.el.div(
                rx.el.div(
                    rx.icon(
                        "triangle_alert",
                        size=24,
                        class_name="text-red-500 mb-2",
                    ),
                    rx.el.h3(
                        "Danger Zone", class_name="text-lg font-bold text-white"
                    ),
                    rx.el.p(
                        "Resetting will revert all blocked sites, user access and bandwidth limits to factory defaults.",
                        class_name="text-slate-400 text-sm max-w-md",
                    ),
                    class_name="flex flex-col",
                ),
                rx.el.button(
                    "Reset All Settings",
                    on_click=DashboardState.reset_settings,
                    class_name="px-6 py-2 bg-red-600/10 border border-red-600/30 text-red-500 hover:bg-red-600/20 rounded-lg font-bold transition-all",
                ),
                class_name="flex flex-col md:flex-row justify-between items-center gap-6",
            ),
            class_name="bg-red-950/20 border border-red-900/30 p-8 rounded-xl mb-12 shadow-inner",
        ),
        class_name="p-6 md:p-10 max-w-7xl mx-auto w-full animate-in fade-in duration-500",
    )