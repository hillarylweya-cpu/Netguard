import reflex as rx
from netguard.states.dashboard_state import DashboardState


def nav_item(label: str, icon_name: str) -> rx.Component:
    is_active = DashboardState.active_page == label
    return rx.el.button(
        rx.icon(
            icon_name,
            class_name=rx.cond(is_active, "text-emerald-400", "text-slate-400"),
        ),
        rx.el.span(label, class_name="ml-3"),
        on_click=lambda: DashboardState.set_active_page(label),
        class_name=rx.cond(
            is_active,
            "flex items-center w-full px-4 py-3 text-sm font-semibold text-emerald-400 bg-slate-800 border-r-4 border-emerald-400 transition-all",
            "flex items-center w-full px-4 py-3 text-sm font-medium text-slate-400 hover:text-slate-100 hover:bg-slate-800/50 transition-all",
        ),
    )


def sidebar() -> rx.Component:
    return rx.el.aside(
        rx.el.div(
            rx.el.div(
                rx.el.div(
                    rx.icon(
                        "shield-check", class_name="text-emerald-500 w-8 h-8"
                    ),
                    rx.el.span(
                        "NET-GUARD",
                        class_name="text-xl font-bold tracking-tighter text-white",
                    ),
                    class_name="flex items-center gap-3",
                ),
                class_name="px-6 py-8",
            ),
            rx.el.nav(
                nav_item("Dashboard", "layout-dashboard"),
                nav_item("Devices", "laptop"),
                nav_item("Bandwidth", "activity"),
                nav_item("Site Blocking", "shield-off"),
                nav_item("Settings", "settings"),
                class_name="mt-4 space-y-1",
            ),
            rx.el.div(
                rx.el.div(
                    rx.el.p(
                        "System Status: Nominal",
                        class_name="text-xs text-slate-500",
                    ),
                    rx.el.p(
                        "v2.4.1-stable",
                        class_name="text-[10px] text-slate-600 font-mono",
                    ),
                    class_name="px-6 py-4 border-t border-slate-800",
                ),
                class_name="absolute bottom-0 w-full",
            ),
            class_name="h-full relative",
        ),
        class_name="w-64 bg-slate-900 border-r border-slate-800 h-screen hidden md:block shrink-0",
    )