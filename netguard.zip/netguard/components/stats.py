import reflex as rx
from netguard.states.dashboard_state import DashboardState


def stat_card(
    label: str, value: str, subtext: str, icon_name: str, color_class: str
) -> rx.Component:
    return rx.el.div(
        rx.el.div(
            rx.el.div(
                rx.icon(icon_name, class_name=f"w-5 h-5 {color_class}"),
                class_name="p-2 bg-slate-900 rounded-lg border border-slate-700",
            ),
            class_name="mb-4",
        ),
        rx.el.p(
            label,
            class_name="text-xs font-semibold text-slate-500 uppercase tracking-wider",
        ),
        rx.el.h3(value, class_name="text-2xl font-bold text-slate-100 mt-1"),
        rx.el.p(subtext, class_name="text-xs text-slate-400 mt-1"),
        class_name="flex-1 min-w-[200px] bg-slate-800 p-6 rounded-xl border border-slate-700 shadow-sm hover:border-slate-600 transition-colors",
    )


def stats_row() -> rx.Component:
    return rx.el.div(
        stat_card(
            "Connected Devices",
            DashboardState.total_devices.to_string(),
            "Active sessions",
            "laptop",
            "text-blue-400",
        ),
        stat_card(
            "Bandwidth Usage",
            f"{DashboardState.bandwidth_usage} Mbps",
            f"Limit: {DashboardState.bandwidth_total} Mbps",
            "zap",
            "text-amber-400",
        ),
        stat_card(
            "Blocked Requests",
            DashboardState.blocked_sites_count.to_string(),
            "Last 24 hours",
            "shield-off",
            "text-red-400",
        ),
        stat_card(
            "Internet Status",
            rx.cond(DashboardState.internet_enabled, "ACTIVE", "INACTIVE"),
            "Global switch state",
            "globe",
            rx.cond(
                DashboardState.internet_enabled,
                "text-emerald-400",
                "text-red-400",
            ),
        ),
        class_name="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 w-full",
    )