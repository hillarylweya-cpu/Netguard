import reflex as rx
from netguard.states.dashboard_state import DashboardState
from netguard.components.sidebar import sidebar
from netguard.components.header import header
from netguard.components.stats import stats_row
from netguard.components.activity import activity_section
from netguard.components.devices import device_management_page
from netguard.components.bandwidth import bandwidth_page
from netguard.components.blocking import site_blocking_page
from netguard.components.settings import settings_page


def dashboard_main() -> rx.Component:
    return rx.el.div(
        rx.el.div(
            rx.el.div(
                rx.el.h1(
                    "Network Control Center",
                    class_name="text-3xl font-extrabold text-white tracking-tight text-center mb-2",
                ),
                rx.el.p(
                    "Institutional Master Killswitch",
                    class_name="text-slate-400 text-center text-sm font-medium mb-10",
                ),
                rx.el.div(
                    rx.el.button(
                        rx.el.div(
                            rx.icon("power", size=48),
                            class_name="flex items-center justify-center",
                        ),
                        on_click=DashboardState.toggle_internet,
                        class_name=rx.cond(
                            DashboardState.internet_enabled,
                            "w-48 h-48 rounded-full bg-slate-900 border-8 border-emerald-500 text-emerald-500 shadow-[0_0_50px_rgba(16,185,129,0.3)] hover:shadow-[0_0_70px_rgba(16,185,129,0.5)] transition-all duration-500 transform hover:scale-105 active:scale-95 flex items-center justify-center relative",
                            "w-48 h-48 rounded-full bg-slate-900 border-8 border-red-500 text-red-500 shadow-[0_0_50px_rgba(239,68,68,0.3)] hover:shadow-[0_0_70px_rgba(239,68,68,0.5)] transition-all duration-500 transform hover:scale-105 active:scale-95 flex items-center justify-center relative",
                        ),
                    ),
                    rx.el.div(
                        rx.el.span(
                            rx.cond(
                                DashboardState.internet_enabled,
                                "SYSTEM ARMED",
                                "SYSTEM DISARMED",
                            ),
                            class_name=rx.cond(
                                DashboardState.internet_enabled,
                                "text-xs font-black text-emerald-500 mt-6 tracking-[0.2em]",
                                "text-xs font-black text-red-500 mt-6 tracking-[0.2em]",
                            ),
                        ),
                        class_name="flex flex-col items-center",
                    ),
                    class_name="flex flex-col items-center justify-center py-10",
                ),
                class_name="max-w-xl mx-auto",
            ),
            class_name="mb-12",
        ),
        stats_row(),
        activity_section(),
        class_name="flex-1 p-6 md:p-10 max-w-7xl mx-auto w-full animate-in fade-in duration-500",
    )


def index() -> rx.Component:
    return rx.el.main(
        rx.el.div(
            sidebar(),
            rx.el.div(
                header(),
                rx.el.div(
                    rx.match(
                        DashboardState.active_page,
                        ("Dashboard", dashboard_main()),
                        ("Devices", device_management_page()),
                        ("Bandwidth", bandwidth_page()),
                        ("Site Blocking", site_blocking_page()),
                        ("Settings", settings_page()),
                        rx.el.div(
                            rx.el.div(
                                rx.icon(
                                    "construction",
                                    size=64,
                                    class_name="text-slate-700 mb-4",
                                ),
                                rx.el.h2(
                                    f"{DashboardState.active_page} Module",
                                    class_name="text-2xl font-bold text-slate-100",
                                ),
                                rx.el.p(
                                    "Module initialization scheduled for next upgrade cycle.",
                                    class_name="text-slate-500 mt-2",
                                ),
                                rx.el.button(
                                    "Return to Dashboard",
                                    on_click=lambda: (
                                        DashboardState.set_active_page(
                                            "Dashboard"
                                        )
                                    ),
                                    class_name="mt-6 px-6 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg font-bold transition-colors",
                                ),
                                class_name="flex flex-col items-center justify-center h-[60vh] text-center",
                            )
                        ),
                    ),
                    class_name="flex-1 overflow-y-auto custom-scrollbar",
                ),
                class_name="flex flex-col flex-1 h-screen overflow-hidden",
            ),
            class_name="flex min-h-screen bg-slate-800 text-slate-200 font-['Inter'] w-full",
        ),
        class_name="w-full",
    )


app = rx.App(
    theme=rx.theme(appearance="light"),
    head_components=[
        rx.el.link(rel="preconnect", href="https://fonts.googleapis.com"),
        rx.el.link(
            rel="preconnect", href="https://fonts.gstatic.com", cross_origin=""
        ),
        rx.el.link(
            href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap",
            rel="stylesheet",
        ),
    ],
)
app.add_page(index, route="/")