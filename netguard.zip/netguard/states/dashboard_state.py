import reflex as rx
from datetime import datetime
from typing import TypedDict


class ActivityLogEntry(TypedDict):
    timestamp: str
    action: str
    status: str
    type: str


class Device(TypedDict):
    id: str
    name: str
    ip: str
    mac: str
    status: str
    department: str
    enabled: bool


class DashboardState(rx.State):
    internet_enabled: bool = True
    total_devices: int = 48
    bandwidth_usage: int = 340
    bandwidth_total: int = 1000
    blocked_sites_count: int = 127
    active_page: str = "Dashboard"
    blocked_sites: dict[str, list[str]] = {
        "Social Media": [
            "facebook.com",
            "twitter.com",
            "instagram.com",
            "tiktok.com",
            "snapchat.com",
        ],
        "Streaming": ["youtube.com", "netflix.com", "twitch.tv", "spotify.com"],
        "Gaming": ["steam.com", "epicgames.com", "roblox.com", "discord.com"],
        "Custom": [],
    }
    category_enabled: dict[str, bool] = {
        "Social Media": True,
        "Streaming": True,
        "Gaming": True,
        "Custom": True,
    }
    new_url_input: str = ""
    selected_category: str = "Custom"
    notification_prefs: dict[str, bool] = {
        "email_alerts": True,
        "push_notifications": False,
        "activity_digest": True,
    }
    admin_name: str = "Chief Admin"
    password_current: str = ""
    password_new: str = ""
    password_confirm: str = ""
    device_filter: str = "All"
    device_search: str = ""
    department_limits: dict[str, int] = {
        "Staff": 200,
        "Students": 100,
        "Labs": 150,
        "Admin": 300,
    }
    devices: list[Device] = [
        {
            "id": "1",
            "name": "Admin-Workstation-01",
            "ip": "192.168.1.10",
            "mac": "00:1A:2B:3C:4D:5E",
            "status": "Online",
            "department": "Admin",
            "enabled": True,
        },
        {
            "id": "2",
            "name": "Staff-Laptop-Alpha",
            "ip": "192.168.2.15",
            "mac": "AA:BB:CC:DD:EE:FF",
            "status": "Online",
            "department": "Staff",
            "enabled": True,
        },
        {
            "id": "3",
            "name": "Lab-PC-42",
            "ip": "192.168.3.42",
            "mac": "11:22:33:44:55:66",
            "status": "Online",
            "department": "Labs",
            "enabled": True,
        },
        {
            "id": "4",
            "name": "Student-Tablet-7",
            "ip": "192.168.4.101",
            "mac": "FF:EE:DD:CC:BB:AA",
            "status": "Offline",
            "department": "Students",
            "enabled": False,
        },
        {
            "id": "5",
            "name": "Admin-Server-Main",
            "ip": "192.168.1.2",
            "mac": "A1:B2:C3:D4:E5:F6",
            "status": "Online",
            "department": "Admin",
            "enabled": True,
        },
        {
            "id": "6",
            "name": "Staff-MacBook-Pro",
            "ip": "192.168.2.20",
            "mac": "55:66:77:88:99:00",
            "status": "Online",
            "department": "Staff",
            "enabled": True,
        },
        {
            "id": "7",
            "name": "Lab-3D-Printer",
            "ip": "192.168.3.12",
            "mac": "99:88:77:66:55:44",
            "status": "Offline",
            "department": "Labs",
            "enabled": True,
        },
        {
            "id": "8",
            "name": "Student-PC-RoomA",
            "ip": "192.168.4.55",
            "mac": "22:44:66:88:AA:CC",
            "status": "Online",
            "department": "Students",
            "enabled": True,
        },
        {
            "id": "9",
            "name": "Library-Terminal-1",
            "ip": "192.168.4.22",
            "mac": "12:34:56:78:90:AB",
            "status": "Online",
            "department": "Labs",
            "enabled": True,
        },
        {
            "id": "10",
            "name": "Staff-Desktop-HR",
            "ip": "192.168.2.33",
            "mac": "BC:DE:F0:12:34:56",
            "status": "Online",
            "department": "Staff",
            "enabled": True,
        },
        {
            "id": "11",
            "name": "Dean-iPad",
            "ip": "192.168.1.15",
            "mac": "DE:AD:BE:EF:CA:FE",
            "status": "Online",
            "department": "Admin",
            "enabled": True,
        },
        {
            "id": "12",
            "name": "Physics-Lab-Rig",
            "ip": "192.168.3.99",
            "mac": "CA:FE:BA:BE:00:11",
            "status": "Online",
            "department": "Labs",
            "enabled": True,
        },
        {
            "id": "13",
            "name": "Student-WiFi-Mobile",
            "ip": "192.168.4.200",
            "mac": "FE:ED:FA:CE:88:99",
            "status": "Offline",
            "department": "Students",
            "enabled": False,
        },
        {
            "id": "14",
            "name": "Staff-Print-Server",
            "ip": "192.168.2.5",
            "mac": "AB:CD:EF:01:23:45",
            "status": "Online",
            "department": "Staff",
            "enabled": True,
        },
        {
            "id": "15",
            "name": "Lab-VR-Headset",
            "ip": "192.168.3.50",
            "mac": "33:66:99:AA:DD:FF",
            "status": "Online",
            "department": "Labs",
            "enabled": True,
        },
    ]
    activity_log: list[ActivityLogEntry] = [
        {
            "timestamp": "11:20 AM",
            "action": "Bandwidth limit adjusted for Students",
            "status": "Modified",
            "type": "warning",
        },
        {
            "timestamp": "11:15 AM",
            "action": "Global internet toggle triggered",
            "status": "Enabled",
            "type": "success",
        },
        {
            "timestamp": "10:45 AM",
            "action": "System boot sequence complete",
            "status": "Stable",
            "type": "success",
        },
        {
            "timestamp": "09:30 AM",
            "action": "New device connected: Lab-PC-04",
            "status": "Connected",
            "type": "success",
        },
        {
            "timestamp": "08:15 AM",
            "action": "Attempted access to blocked site: gaming.top",
            "status": "Blocked",
            "type": "danger",
        },
        {
            "timestamp": "07:45 AM",
            "action": "Nightly backup routine complete",
            "status": "Success",
            "type": "success",
        },
        {
            "timestamp": "06:00 AM",
            "action": "System self-check",
            "status": "Nominal",
            "type": "success",
        },
        {
            "timestamp": "05:30 AM",
            "action": "Unauthorized IP login attempt detected",
            "status": "Blocked",
            "type": "danger",
        },
    ]

    @rx.var
    def filtered_devices(self) -> list[Device]:
        data = self.devices
        if self.device_filter != "All":
            data = [d for d in data if d["department"] == self.device_filter]
        if self.device_search:
            search = self.device_search.lower()
            data = [
                d
                for d in data
                if search in d["name"].lower() or search in d["ip"]
            ]
        return data

    @rx.var
    def department_stats(self) -> dict[str, int]:
        stats = {"All": len(self.devices)}
        for dpt in ["Staff", "Students", "Labs", "Admin"]:
            stats[dpt] = len(
                [d for d in self.devices if d["department"] == dpt]
            )
        return stats

    @rx.var
    def bandwidth_chart_data(self) -> list[dict[str, str | int]]:
        return [
            {
                "name": "Staff",
                "Usage": 145,
                "Limit": self.department_limits.get("Staff", 0),
            },
            {
                "name": "Students",
                "Usage": 85,
                "Limit": self.department_limits.get("Students", 0),
            },
            {
                "name": "Labs",
                "Usage": 110,
                "Limit": self.department_limits.get("Labs", 0),
            },
            {
                "name": "Admin",
                "Usage": 40,
                "Limit": self.department_limits.get("Admin", 0),
            },
        ]

    @rx.var
    def total_allocated(self) -> int:
        return sum(self.department_limits.values())

    @rx.event
    def toggle_internet(self):
        self.internet_enabled = not self.internet_enabled
        new_status = "Online" if self.internet_enabled else "Offline"
        log_type = "success" if self.internet_enabled else "danger"
        now = datetime.now().strftime("%I:%M %p")
        self.activity_log.insert(
            0,
            {
                "timestamp": now,
                "action": f"Global internet access toggled {new_status}",
                "status": new_status,
                "type": log_type,
            },
        )
        if len(self.activity_log) > 10:
            self.activity_log = self.activity_log[:10]
        yield rx.toast(f"Global Internet {new_status}")

    @rx.event
    def toggle_device(self, device_id: str):
        device_name = ""
        new_enabled = False
        for device in self.devices:
            if device["id"] == device_id:
                device["enabled"] = not device["enabled"]
                device_name = device["name"]
                new_enabled = device["enabled"]
                status_str = "Enabled" if device["enabled"] else "Disabled"
                log_type = "success" if device["enabled"] else "warning"
                now = datetime.now().strftime("%I:%M %p")
                self.activity_log.insert(
                    0,
                    {
                        "timestamp": now,
                        "action": f"Device {device['name']} internet access {status_str.lower()}",
                        "status": status_str,
                        "type": log_type,
                    },
                )
                break
        if len(self.activity_log) > 10:
            self.activity_log = self.activity_log[:10]
        yield rx.toast(
            f"Device {device_name} access {('granted' if new_enabled else 'revoked')}"
        )

    @rx.event
    def add_blocked_site(self, form_data: dict):
        url = form_data.get("url", "").strip()
        if not url:
            return
        cat = self.selected_category
        if url not in self.blocked_sites[cat]:
            self.blocked_sites[cat].append(url)
            self.blocked_sites_count += 1
            now = datetime.now().strftime("%I:%M %p")
            self.activity_log.insert(
                0,
                {
                    "timestamp": now,
                    "action": f"Blocked new URL: {url}",
                    "status": "Success",
                    "type": "success",
                },
            )
            yield rx.toast(f"Added {url} to {cat} blocklist")
            self.new_url_input = ""

    @rx.event
    def remove_blocked_site(self, category: str, url: str):
        if url in self.blocked_sites[category]:
            self.blocked_sites[category].remove(url)
            self.blocked_sites_count -= 1
            yield rx.toast(f"Unblocked {url}")

    @rx.event
    def toggle_category(self, category: str):
        self.category_enabled[category] = not self.category_enabled[category]
        status = "Restricted" if self.category_enabled[category] else "Allowed"
        yield rx.toast(f"{category} filtering {status}")

    @rx.event
    def toggle_notification_pref(self, pref_name: str):
        self.notification_prefs[pref_name] = not self.notification_prefs[
            pref_name
        ]

    @rx.event
    def update_password(self):
        if self.password_new != self.password_confirm:
            yield rx.toast("Passwords do not match", type="error")
            return
        if not self.password_current:
            yield rx.toast("Current password required", type="error")
            return
        yield rx.toast("Password updated successfully")
        self.password_current = ""
        self.password_new = ""
        self.password_confirm = ""

    @rx.event
    def reset_settings(self):
        self.notification_prefs = {
            "email_alerts": True,
            "push_notifications": False,
            "activity_digest": True,
        }
        self.category_enabled = {k: True for k in self.category_enabled.keys()}
        yield rx.toast("All system settings have been reset")

    @rx.event
    def set_device_filter(self, filter_val: str):
        self.device_filter = filter_val

    @rx.event
    def set_device_search(self, search_val: str):
        self.device_search = search_val

    @rx.event
    def adjust_bandwidth(self, department: str, amount: int):
        current = self.department_limits.get(department, 0)
        new_val = max(0, min(1000, current + amount))
        self.department_limits[department] = new_val

    @rx.event
    def set_active_page(self, page_name: str):
        self.active_page = page_name