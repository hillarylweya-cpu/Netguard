# Institution Internet Control Panel

## Design Direction
- Dark admin theme with a deep navy/slate background
- Emerald-green accent color for active/enabled states, red for disabled/blocked
- Clean flat cards with subtle borders, modern dashboard aesthetic
- Sidebar navigation (dark), top header with admin identity and status indicators
- Typography: Inter font, bold headings, clean data presentation

---

## Phase 1: Dashboard Layout, Navigation & Master ON/OFF Toggle ✅
- [x] Build sidebar navigation with links: Dashboard, Devices, Bandwidth, Site Blocking, Settings
- [x] Create top header with admin name, institution name, and global internet status indicator
- [x] Build main dashboard page with large master ON/OFF toggle button (controls entire institution internet)
- [x] Add status cards: Total Devices Connected, Current Bandwidth Usage, Blocked Sites Count, Internet Status
- [x] Add recent activity log section showing last 10 actions taken by admin

---

## Phase 2: Device Management & Bandwidth Control ✅
- [x] Build Device Management page with table of connected devices (name, IP, MAC, status, department)
- [x] Add ability to enable/disable internet per device with toggle switches
- [x] Add device grouping by department (e.g., Staff, Students, Labs, Admin)
- [x] Build Bandwidth Control page with sliders/inputs for setting speed limits per department/device group
- [x] Add bandwidth usage visualization (bar chart showing usage per department)

---

## Phase 3: Site Blocking, Activity Logs & Settings ✅
- [x] Build Site Blocking page with form to add/remove blocked URLs
- [x] Add categorized block lists (Social Media, Streaming, Gaming, Custom)
- [x] Add toggle to enable/disable entire block categories with one click
- [x] Build Settings page with admin password change, notification preferences, and system info
- [x] Add comprehensive activity/audit log page with filters (date, action type, target device)
