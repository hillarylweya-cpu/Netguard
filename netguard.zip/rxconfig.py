import reflex as rx

config = rx.Config(app_name="netguard", plugins=[rx.plugins.TailwindV3Plugin()])
